Any individual or institution is granted permission for use, copying, or redistribution of
these 3D models and associated documentation, provided that such code and documentation are
not sold for profit. 

The 3D models provided here are free of charge, and can be used as samples for the GUImorph package. 
These models are for excersice only. They are not completed and may contain flaws. We strongly suggest these are not
used for research without consulting Dr. Erik Otarola-Castillo (Purdue University; eoc@purdue.edu) or 
Dr. Michael J. Shott (University of Akron; shott@uakron.edu).

Acknowledgements go to Dr. Shott for kindly making these data available.